#include <iostream>
#include <fstream>
#include <string>
using namespace std;

bool registerUser(const string& username, const string& password) {
    ifstream infile("users.txt");
    string u, p;

    while (infile >> u >> p) {
        if (u == username) {
            cout << "Username already exists.\n";
            return false;
        }
    }

    infile.close();

    ofstream outfile("users.txt", ios::app);
    outfile << username << " " << password << endl;
    cout << "Registration successful.\n";
    return true;
}

bool loginUser(const string& username, const string& password) {
    ifstream infile("users.txt");
    string u, p;

    while (infile >> u >> p) {
        if (u == username && p == password) {
            cout << "Login successful. Welcome, " << username << "!\n";
            return true;
        }
    }

    cout << "Invalid username or password.\n";
    return false;
}

int main() {
    int choice;
    string username, password;

    cout << "1. Register\n2. Login\nEnter choice: ";
    cin >> choice;

    cout << "Enter username: ";
    cin >> username;
    cout << "Enter password: ";
    cin >> password;

    if (choice == 1) {
        registerUser(username, password);
    } else if (choice == 2) {
        loginUser(username, password);
    } else {
        cout << "Invalid choice.\n";
    }

    return 0;
}