# Login Registration System

This project is part of the CodeAlpha C++ Internship.

## How to Run
1. Compile using any C++ compiler (e.g., `g++ main.cpp -o main`)
2. Run the program (`./main` or `main.exe`)
